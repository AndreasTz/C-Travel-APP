#ifndef _CONSTANTS_
#define _CONSTANTS_

#define MINIMUM_BUFFER_SIZE 2048
/* Symfwna me sxetiko thread sto piazza mas to epitrepsate */

/* Ta 3 pithana apotelesmata mias aithshs kwdikopoihmena */
#define NOT_VACCINATED 0
#define VACCINE_OUT_OF_TIME 1
#define VACCINATED 2


#endif